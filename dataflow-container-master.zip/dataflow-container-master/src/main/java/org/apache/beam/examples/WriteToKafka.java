package org.apache.beam.examples;


import com.google.api.client.json.Json;
import com.google.cloud.monitoring.v3.MetricServiceClient;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParser;
import com.google.monitoring.v3.ListTimeSeriesRequest;
import com.google.monitoring.v3.Point;
import com.google.monitoring.v3.TimeInterval;
import com.google.monitoring.v3.TimeSeries;
import com.google.protobuf.util.Timestamps;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.coders.CoderRegistry;
import org.apache.beam.sdk.coders.StringUtf8Coder;
import org.apache.beam.sdk.io.TextIO;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubIO;
import org.apache.beam.sdk.io.kafka.KafkaIO;
import org.apache.beam.sdk.options.*;
import org.apache.beam.sdk.transforms.*;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.PCollection;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;
import java.io.IOException;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.PCollectionTuple;
import org.apache.beam.sdk.values.TupleTag;
import org.apache.kafka.common.serialization.StringSerializer;
import org.joda.time.Duration;

public class WriteToKafka {

    private final static Logger LOGGER = Logger.getLogger(WriteToKafka.class.getName());

    /** The tag for the main output for the UDF. */
    private static final TupleTag<FailsafeElement<String, String>> UDF_OUT =
            new TupleTag<FailsafeElement<String, String>>() {};

    /** The tag for the dead-letter output of the udf. */
    static final TupleTag<FailsafeElement<String, String>> UDF_DEADLETTER_OUT =
            new TupleTag<FailsafeElement<String, String>>() {};

/*
    */
/** The tag for the main output of the json transformation. *//*

    static final TupleTag<String> TRANSFORM_OUT = new TupleTag<String>() {};

    */
/** The tag for the dead-letter output of the json to table row transform. *//*

    static final TupleTag<FailsafeElement<String, String>>
            TRANSFORM_DEADLETTER_OUT = new TupleTag<FailsafeElement<String, String>>() {};

*/

    static class MetricToKafkaMessage
            extends PTransform<PCollection<String>, PCollectionTuple> {

        private final DFOptions options;

        MetricToKafkaMessage(DFOptions options) {
            this.options = options;
        }

        @Override
        public PCollectionTuple expand(PCollection<String> input) {

            PCollectionTuple udfOut =
                    input
                            // Map the incoming messages into FailsafeElements so we can recover from failures
                            // across multiple transforms.
                            .apply("MapToRecord", ParDo.of(new MakeFailSafe()))
                            .apply(
                                    "InvokeUDF",
                                    JavascriptTextTransformer.FailsafeJavascriptUdf.<String>newBuilder()
                                            .setFileSystemPath(options.getJavascriptTextTransformGcsPath())
                                            .setFunctionName(options.getJavascriptTextTransformFunctionName())
                                            .setSuccessTag(UDF_OUT)
                                            .setFailureTag(UDF_DEADLETTER_OUT)
                                            .build());
            // Re-wrap the PCollections so we can return a single PCollectionTuple
            return PCollectionTuple.of(UDF_OUT, udfOut.get(UDF_OUT))
                    .and(UDF_DEADLETTER_OUT, udfOut.get(UDF_DEADLETTER_OUT));
        }
    }

    /*
    ** This is used to get the transformed payload that is returned by the UDF.
     */
    static class GetPayload extends DoFn<FailsafeElement<String, String>, String>{
        @ProcessElement
        public void processElement(ProcessContext context){
            FailsafeElement element = context.element();
            context.output((String) element.getPayload());
        }
    }

    /*
    ** This is used to get the original payload from the FailSafe element, this is called when returning the failed objects
     */
    static class GetOriginalPayload extends DoFn<FailsafeElement<String, String>, String>{
        @ProcessElement
        public void processElement(ProcessContext context){
            FailsafeElement element = context.element();
            context.output((String) element.getOriginalPayload());
        }
    }

    /*
    ** Wraps the incoming Json string payload into a FailSafe object so that we can recover from issues when the UDF
    * is called
     */
    static class MakeFailSafe extends DoFn<String, FailsafeElement<String, String>>{
        @ProcessElement
        public void processElement(ProcessContext context){
            String message = context.element();
            context.output(FailsafeElement.of(message,message));
        }
    }

    static class SplitFilterList extends DoFn<String, String> {
        MetricServiceClient metricServiceClient = null;
        //Each instance of SplitFilterList will get it's own MetricServiceClient object
        @Setup
        public void setup(){
            try {
                metricServiceClient = MetricServiceClient.create();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        @Teardown
        public void teardown(){
            metricServiceClient.shutdown();
        }

        //This function is responsible for taking the TimeSeries message that is returned and converting it into
        //The JSON format that the Javascript UDF will consume
        public String buildJsonFromTimeseries(TimeSeries message){
            Gson gson = new Gson();
            List<String> labelMaps = new ArrayList<String>();
            List<String> resourceLabelMaps = new ArrayList<String>();
            List<Point> pointsList = new ArrayList<>();

            message.getMetric().getLabelsMap().forEach((k, v) -> labelMaps.add(k + ":" + v));
            message.getResource().getLabelsMap().forEach((k, v) -> resourceLabelMaps.add(k + ":" + v));
            message.getPointsList().iterator().forEachRemaining(point -> pointsList.add(point));

            String kind = message.getMetricKind().toString();
            String metricType = message.getMetric().getType();
            String resourceType = message.getResource().getType();
            String[] categoryTemp = metricType.split("/");
            String category = categoryTemp[categoryTemp.length-1];
            String name = categoryTemp[categoryTemp.length-2];

            /*
            ** Build a HashMap that we can add the values acquired above to, this will in turn be converted into a
            * JSON object using the GSON library.
             */
            Map<String, Object> toBuild = new HashMap<>();

            for(String s: labelMaps){
                String[] split = s.split(":");
                if(split.length > 1) {
                    toBuild.put("tag_" + split[0], split[1]);
                }
                else{
                    toBuild.put("tag_" + split[0], "No Value Returned");
                }
            }
            for(String s: resourceLabelMaps){
                String[] split = s.split(":");
                toBuild.put("tag_" + split[0], split[1]);
            }
            for (Point s: pointsList){
                toBuild.put("field_" + category, s.getValue().toString().split(":")[1].replace("\n", ""));

            }
            toBuild.put("timestamp",pointsList.get(0).getInterval().getStartTime().toString().split(":")[1].replace("\n",""));
            toBuild.put("tag_Kind",kind);
            toBuild.put("tag_MetricType",metricType);
            toBuild.put("tag_ResourceType",resourceType);
            toBuild.put("name", name);
            String output = gson.toJson(toBuild);

            return output;
        }

        @ProcessElement
        public void processElement(@Element String filter, OutputReceiver<String> out){
            final Logger LOGGER = Logger.getLogger(SplitFilterList.class.getName());
            //Split incoming line from Configuration file
            String[] temp = filter.split(":");

            //First element of the configuration file line is the metric
            String metricFilter = temp[0];
            //Second element of the configuration file line is the new value lag
            int seconds = Integer.parseInt(temp[1]);
            //Third element is the project name
            String project = temp[2];
            //Build project string
            project = "projects/" + project;

            //Build start time for polling
            long startMillis = System.currentTimeMillis() - ((seconds) * 1000);

            //Build TimeInterval from startMillis ago to now
            TimeInterval interval =
                    TimeInterval.newBuilder()
                            .setStartTime(Timestamps.fromMillis(startMillis))
                            .setEndTime(Timestamps.fromMillis(System.currentTimeMillis()))
                            .build();

            /*
            ** Build the ListTimeSeries request, this is what we call using the MetricServiceClient to poll the metrics
             */
            ListTimeSeriesRequest request =
                    ListTimeSeriesRequest.newBuilder()
                            .setName(project)
                            .setFilter(metricFilter)
                            .setInterval(interval)
                            .build();

            //Paged response returns a series of TimeSeries elements that contain the metric data
            MetricServiceClient.ListTimeSeriesPagedResponse response
                    = metricServiceClient.listTimeSeries(request);

            //Iterate through the timeseries returned from the metric poll request and format them
            response.iterateAll().forEach(timeSeries -> out.output(buildJsonFromTimeseries(timeSeries)));
        }
    }

    /*
    ** BuildRequests is our first transformation, it receives the PCollection of Strings == Metric list read from Pub/Sub
    * And applies a ParDo that splits the metric list into individual metrics, makes the API request to poll the metric,
    * formats the result and returns
     */
    public static class BuildRequests
            extends PTransform<PCollection<String>, PCollection<String>>{
        @Override
        public PCollection<String> expand(PCollection<String> lines) {
            //Each line is similiar to:  "metric.type = \"storage.googleapis.com/storage/total_bytes\"":600

            // Split line separated by : into their component elements
            PCollection<String> responseText = lines.apply(ParDo.of(new WriteToKafka.SplitFilterList()));

            return responseText;
        }
    }

    public interface DFOptions extends PipelineOptions, StreamingOptions {

        /** Set this required option to specify where to write the output. */
        @Description("Kafka Output Topic Name")
        @Default.String("wm-trevor")
        String getKafkaOutputTopic();
        void setKafkaOutputTopic(String value);

        /** The project ID for the project we are using */
        @Description("Project ID")
        @Default.String("jc-gkeop-2")
        String getProjectID();
        void setProjectID(String projectID);

        //BigQuery Dataset to use
        @Description("Kafka Bootstrap Servers")
        @Default.String("10.12.1.16:9092")
        String getKafkaBootstrap();
        void setKafkaBootstrap(String bootstrap);

        @Description("Project String used by Monitoring API")
        @Default.String("projects/jc-gkeop-2")
        String getMonitoringProject();
        void setMonitoringProject(String value);

        @Description("Filter list file to read from")
        @Default.String("gs://jc-gkeop-2-df-temp/FilterList.csv")
        String getMetricList();
        void setMetricList(String value);

        @Description("Output topic for PubSub")
        @Default.String("projects/jc-gkeop-2/topics/metric-values")
        String getOutputTopic();
        void setOutputTopic(String value);

        @Description("Subscription to read metric list from")
        @Default.String("projects/jc-gkeop-2/subscriptions/metric-list-sub")
        String getInputSubscription();
        void setInputSubscription(String value);

        @Description("Gcs path to javascript udf source")
        @Default.String("gs://jc-gkeop-2-df-temp/TestUDF.js")
        String getJavascriptTextTransformGcsPath();
        void setJavascriptTextTransformGcsPath(String javascriptTextTransformGcsPath);

        @Description("UDF Javascript Function Name")
        @Default.String("transform")
        String getJavascriptTextTransformFunctionName();
        void setJavascriptTextTransformFunctionName(String javascriptTextTransformFunctionName);

    }

    public static void run(String[] args){
        PipelineOptionsFactory.register(WriteToKafka.DFOptions.class);
        Duration DEFAULT_POLL_INTERVAL = Duration.standardSeconds(60);
        WriteToKafka.DFOptions options = PipelineOptionsFactory.fromArgs(args).withValidation().as(WriteToKafka.DFOptions.class);
        options.setStreaming(true);

        //Create pipeline with options
        Pipeline p = Pipeline.create(options);

        //FailsafeElementCoder is used to encode/decode failsafe elements, failsafe elements allow us to recover from
        //failures mid-stream and still output some result
        FailsafeElementCoder<String, String> coder =
                FailsafeElementCoder.of(StringUtf8Coder.of(),StringUtf8Coder.of());

        CoderRegistry coderRegistry = p.getCoderRegistry();
        coderRegistry.registerCoderForType(coder.getEncodedTypeDescriptor(), coder);

        /*
         * Steps:
         *  1) Get list of metrics to monitor from Pub/Sub
         *  2) Poll Google Cloud Metrics API for each metric in the list
         *  3) Transform the metric JSON payload into Messages to send to Kafka
         *     - Transform json payload via UDF
         *     - Convert UDF result to Kafka Message
         *  4) Write successful messages to Kafka
         *  5) Write failed messages to PubSub
         */

        /*
        **Step 1 -- Read list of Metrics to monitor from Pub/Sub
         */
        PCollectionTuple tuple = p.apply("ReadMetricsList", PubsubIO.readStrings().fromSubscription(options.getInputSubscription()))
        //p.apply("ReadLines", TextIO.read().from(options.getMetricList()).watchForNewFiles(DEFAULT_POLL_INTERVAL, Watch.Growth.never()))
                /*
                ** Step 2 -- Poll metrics for each metric in the list
                 */
                .apply("Poll Metrics", new BuildRequests())
                /*
                ** Step 3 -- Wrap metric result JSON in FailSafeElements FailSafeElement(Original value, Transformed Value)
                 */
                .apply("Build Failsafe Elements", new MetricToKafkaMessage(options));

                /*
                ** Step 4 -- Write Successful transforms to Kafka
                 */
        PCollection<FailsafeElement<String, String>> successfulCollection =
            tuple.get(UDF_OUT);
                successfulCollection.apply("Get Successful Payload", ParDo.of(new GetPayload()))
                //.apply("Write Successful to PubSub", PubsubIO.writeStrings().to(options.getOutputTopic()));
                .apply("WriteToKafka", KafkaIO.<Void, String>write()
         .withBootstrapServers(options.getKafkaBootstrap())
         .withTopic(options.getKafkaOutputTopic())
         .withValueSerializer(StringSerializer.class).values());

        /*
        ** Step 5 -- Write failed transforms to Pub/Sub
         */
        PCollection<FailsafeElement<String, String>> failedCollection =
                tuple.get(UDF_DEADLETTER_OUT);
        failedCollection.apply("Get Failed Payload", ParDo.of(new GetOriginalPayload()))
                .apply("Write Failed to PubSub", PubsubIO.writeStrings().to(options.getOutputTopic()));
        //.apply("WriteToKafka", KafkaIO.<Void, String>write()
        //.withBootstrapServers(options.getKafkaBootstrap())
        //.withTopic(options.getKafkaOutputTopic())
        //.withValueSerializer(StringSerializer.class).values());

        p.run();
    }

    public static void main(String[] args){
        String[] test = {"--kafkaOutputTopic=wm-trevor", "--kafkaBootstrap=10.12.1.16:9092", "--projectID=jc-gkeop-2", "--runner=DirectRunner"};
        run(args);
    }
}
