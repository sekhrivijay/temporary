package org.apache.beam.examples;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.api.Metric;
import com.google.cloud.monitoring.v3.MetricServiceClient;
import com.google.gson.*;
import com.google.gson.stream.JsonReader;
import com.google.monitoring.v3.ListTimeSeriesRequest;
import com.google.monitoring.v3.Point;
import com.google.monitoring.v3.TimeInterval;
import com.google.monitoring.v3.TimeSeries;
import com.google.protobuf.util.Timestamps;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class JsonTester {


    public String buildJsonFromTimeseries(TimeSeries message){
        Gson gson = new Gson();
        List<String> labelMaps = new ArrayList<String>();
        List<String> resourceLabelMaps = new ArrayList<String>();
        List<Point> pointsList = new ArrayList<>();

        message.getMetric().getLabelsMap().forEach((k, v) -> labelMaps.add(k + ":" + v));
        message.getResource().getLabelsMap().forEach((k, v) -> resourceLabelMaps.add(k + ":" + v));
        message.getPointsList().iterator().forEachRemaining(point -> pointsList.add(point));

        String kind = message.getMetricKind().toString();
        String metricType = message.getMetric().getType();
        String resourceType = message.getResource().getType();
        String[] categoryTemp = metricType.split("/");
        String category = categoryTemp[categoryTemp.length-1];
        String name = categoryTemp[categoryTemp.length-2];
        Map<String, Object> toBuild = new HashMap<>();

        for(String s: labelMaps){
            String[] split = s.split(":");
            toBuild.put("tag_" + split[0], split[1]);
        }
        for(String s: resourceLabelMaps){
            String[] split = s.split(":");
            toBuild.put("tag_" + split[0], split[1]);
        }
        for (Point s: pointsList){
            toBuild.put("field_" + category, s.getValue().toString().split(":")[1].replace("\n", ""));

        }
        toBuild.put("timestamp",pointsList.get(0).getInterval().getStartTime().toString().split(":")[1].replace("\n",""));
        toBuild.put("tag_Kind",kind);
        toBuild.put("tag_MetricType",metricType);
        toBuild.put("tag_ResourceType",resourceType);
        toBuild.put("name", name);
        String output = gson.toJson(toBuild);

        return output;
    }

    public static void main(String[] args) throws IOException {
        JsonTester tester = new JsonTester();
        MetricServiceClient metricServiceClient = null;

            try {
                metricServiceClient = MetricServiceClient.create();
            } catch (IOException e) {
                e.printStackTrace();
            }

            String metricFilter = "metric.type = \"bigquery.googleapis.com/storage/stored_bytes\"";
            int seconds = 10800;
            String project = "jc-gkeop-2";
            project = "projects/" + project;

            long startMillis = System.currentTimeMillis() - ((seconds) * 1000);
            TimeInterval interval =
                    TimeInterval.newBuilder()
                            .setStartTime(Timestamps.fromMillis(startMillis))
                            .setEndTime(Timestamps.fromMillis(System.currentTimeMillis()))
                            .build();

            ListTimeSeriesRequest request =
                    ListTimeSeriesRequest.newBuilder()
                            .setName(project)
                            .setFilter(metricFilter)
                            .setInterval(interval)
                            .build();
            MetricServiceClient.ListTimeSeriesPage response2 = metricServiceClient.listTimeSeries(request).getPage();
          MetricServiceClient.ListTimeSeriesPagedResponse response
                    = metricServiceClient.listTimeSeries(request);
        Gson gson = new GsonBuilder().serializeNulls().create();
        List<String> labels = new ArrayList<String>();

        response.iterateAll().forEach(timeSeries -> System.out.println(tester.buildJsonFromTimeseries(timeSeries)));

    }
}
