package org.apache.beam.examples;

import io.grpc.StatusRuntimeException;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.options.*;

import javax.sound.sampled.SourceDataLine;
import java.nio.channels.Pipe;

public class Push_to_BigQuery {

    public interface DFOptions extends PipelineOptions{
        @Description("Path of the file to read from")
        @Validation.Required
        String getInputFile();
        void setInputFile(String value);

        /** Set this required option to specify where to write the output. */
        @Description("Output BigQuery Table")
        @Validation.Required
        String getOutputTable();
        void setOutputTable(String value);

        /** The project ID for the project we are using */
        @Description("Project ID")
        @Validation.Required
        String getProjectID();
        void setProjectID(String projectID);

        //BigQuery Dataset to use
        @Description("Dataset within BigQuery you want to write the table to")
        @Validation.Required
        String getOutputDataset();
        void setOutputDataset(String outputDataset);
    }

    public void run(String[] args){
        PipelineOptionsFactory.register(DFOptions.class);
        DFOptions options = PipelineOptionsFactory.fromArgs(args).withValidation().as(DFOptions.class);

        Pipeline p = Pipeline.create(options);

    }

    public static void main(String[] args){
        Push_to_BigQuery ourJob = new Push_to_BigQuery();
        ourJob.run(args);
    }

}
