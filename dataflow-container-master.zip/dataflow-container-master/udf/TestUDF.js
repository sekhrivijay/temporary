function transform(inJson) {
    var obj;
    
    if (typeof inJson == "string") {
      obj = JSON.parse(inJson);
    }
    else {
      obj = inJson;
    }
    
    var ret = {
        name: obj.name.trim(),
        timestamp: obj.timestamp.trim(),
        fields: {},
        tags: {}
    };


    for(var i in obj) {
      var prop = i;
      var value = '';
      
      if (prop.indexOf('tag_') > -1) {
        prop = prop.replace('tag_', '');
        value = obj[i];
        ret.tags[prop] = value.trim();
      }
      else if (prop.indexOf('field_') > -1) {
        prop = prop.replace('field_', '');
        value = obj[i];
        ret.fields[prop] = value.trim();
      }
    }
    
    var str = JSON.stringify(ret);

    return str;
}
