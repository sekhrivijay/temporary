# dataflow-container


# GitLab
[GitLab Instance](http://35.184.20.186/)

GitLab is locked down to only specific IPs through the firewall.

# Jenkins
[Jenkins Instance](http://34.72.215.174/)

Jenkins is setup with OAuth to GitLab and locked down to only specific IPs through the firewall.

## Jenkins Build Process

1. On Push Event to GitLab the latest code for the pipeline is pulled.
2. We execute the following shell command to build the JAR and store the Dataflow template on a Google Cloud Storage Bucket:
```
mvn compile exec:java -Dexec.mainClass=org.apache.beam.examples.WriteToKafka -Pdataflow-runner -Dexec.args="--runner=DataflowRunner --project=jc-gkeop-2 --region=us-central1 --gcpTempLocation=gs://jc-gkeop-2-df-temp/tmp --subnetwork=regions/us-central1/subnetworks/kafka-net-1-sn01 --stagingLocation=gs://wm_dataflow_templates/staging --templateLocation=gs://wm_dataflow_templates/templates/write-to-kafka"
```
3. Push the latest UDF to Google Cloud Storage.
```
gsutil cp ./udf/TestUDF.js gs://jc-gkeop-2-df-temp/TestUDF.js
```
4. Next we look for any existing streaming job and start the drain process so it no longer accepts new input.
```
PREVJOB=$(gcloud dataflow jobs list --region us-central1 | grep stream-test- | awk '{print $1}')
gcloud dataflow jobs drain $PREVJOB || true
```
5. Finally we kick off the new streaming job based on the previously built template.
```
gcloud dataflow jobs run "stream-test-`date +%Y%m%d-%H%M%S`" --gcs-location gs://wm_dataflow_templates/templates/write-to-kafka --num-workers=2 --max-workers=5
```

# CI Flow

![Stream Job CI Flow](/ci-flow.png "Stream Job CI Flow")

